﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BusinessRulesEngine.Models
{
    // Email Model
    public class EmailModel
    {
        public string Email { get; set; }

        public string Description { get; set; }

        public string BodyText { get; set; }
    }
}
