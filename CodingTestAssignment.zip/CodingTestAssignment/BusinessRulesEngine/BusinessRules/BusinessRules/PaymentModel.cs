﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BusinessRulesEngine.Models
{
    public class PaymentModel
    {
        // Define Properties associated
    }
}
