﻿using BusinessRulesEngine.Models;
using System;

namespace BusinessRulesEngine.BusinessRules
{
    public class SendEmail : ISendEmail
    {
        // Send Email Trigger
        public void SendEmailAndUpdateForUpgrade(EmailModel emailModel)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
