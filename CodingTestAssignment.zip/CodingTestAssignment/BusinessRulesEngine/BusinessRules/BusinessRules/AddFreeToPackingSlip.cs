﻿using BusinessRulesEngine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BusinessRulesEngine.BusinessRules
{
    public class AddFreeToPackingSlip : IAddFreeToPackingSlip
    {        
        // Add Free Subscription
        public void AddFreeSubscription(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
