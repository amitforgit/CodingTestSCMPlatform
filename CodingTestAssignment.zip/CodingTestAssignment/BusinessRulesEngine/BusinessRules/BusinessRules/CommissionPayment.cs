﻿using BusinessRulesEngine.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BusinessRulesEngine.BusinessRules
{
    public class CommissionPayment : ICommissionPayment
    {        
        // Generate Commission Payment Class
        public void GenerateCommissionPayment(PaymentModel PaymentMethod)
        {
            // To implement the logic
            throw new NotImplementedException();
        }
    }
}
