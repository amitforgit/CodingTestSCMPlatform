﻿using System;

namespace BusinessRules
{
    // Business Model to keep data
    public class BusinessModel
    {

    }
}
